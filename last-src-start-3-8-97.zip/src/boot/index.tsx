import app from "./setup";

export default function() {
	return app;
}
