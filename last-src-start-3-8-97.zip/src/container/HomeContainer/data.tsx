export default [
	"React Native Starter Kit",
	"React Navigation",
	"NativeBase Easy Grid",
	"NativeBase",
	"CodePush",
	"Redux",
];
