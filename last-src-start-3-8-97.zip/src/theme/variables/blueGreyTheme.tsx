import themeCreator from "./themeCreator";
import Colors from "../color";
const color = Colors("primary");
const theme = themeCreator(color);
export default theme;
