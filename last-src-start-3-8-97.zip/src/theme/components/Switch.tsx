export default () => {
	const switchTheme = {
		marginVertical: -5,
	};

	return switchTheme;
};
