export default () => {
	const rightTheme = {
		"NativeBase.Button": {
			alignSelf: undefined,
		},
		flex: 1,
		alignSelf: "center",
		alignItems: "flex-end",
	};

	return rightTheme;
};
